To compile use the Makefile
make

To run the program:
./a.out <imageName>

e.g
./a.out dart0

This will output in detected.jpg

To run for all images:
make runall

Outputs will be found in the output directory.